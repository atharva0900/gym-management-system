import React from "react";
import { NavLink, Outlet } from "react-router-dom";

export default function Dashboard() {
  return (
    <div className="container py-4">
      <div className="d-flex gap-2 mb-3 flex-wrap">
        <NavLink className="btn btn-outline-primary" to={"/dashboard"}>
          Packages
        </NavLink>
        <NavLink
          className="btn btn-outline-primary"
          to={"/dashboard/add-package"}
        >
          Add Package
        </NavLink>
        <NavLink
          className="btn btn-outline-primary"
          to={"/dashboard/manage-trainers"}
        >
          Trainers
        </NavLink>
        <NavLink
          className="btn btn-outline-primary"
          to={"/dashboard/add-trainer"}
        >
          Add Trainer
        </NavLink>
        <NavLink
          className="btn btn-outline-primary"
          to={"/dashboard/manage-members"}
        >
          Members
        </NavLink>
        <NavLink
          className="btn btn-outline-primary"
          to={"/dashboard/manage-memberships"}
        >
          Memberships
        </NavLink>
      </div>
      <Outlet />
    </div>
  );
}
