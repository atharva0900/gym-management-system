// import React, { useContext } from "react";
// import { useForm } from "react-hook-form";
// import Swal from "sweetalert2";
// import { LoginContext } from "../context/LoginContext";
// import { useNavigate } from "react-router-dom";

// const BASE = "http://localhost:8080";

// export default function Login() {
//   const { register, handleSubmit } = useForm();
//   const { setIsLogin, setUserId, setRole } = useContext(LoginContext);
//   const navigate = useNavigate();

//   const onSubmit = async (form) => {
//     try {
//       if (form.role === "customer") {
//         const res = await fetch(`${BASE}/api/customers/login`, {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ email: form.email, password: form.password }),
//         });

//         const obj = await res.json();
//         if (res.ok) {
//           const user = obj.data;
//           setIsLogin(true);
//           setUserId(user?.id ?? null);
//           setRole("customer");
//           Swal.fire("Welcome", obj.message || "Login successful", "success");
//           navigate("/");
//         } else {
//           Swal.fire(
//             "Failed",
//             obj.message || "Invalid customer credentials",
//             "error"
//           );
//         }
//       } else if (form.role === "admin") {
//         const res = await fetch(`${BASE}/api/admin/login`, {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({ email: form.email, password: form.password }),
//         });

//         const obj = await res.json();
//         if (res.ok) {
//           const admin = obj.data;
//           setIsLogin(true);
//           setUserId(admin?.id ?? null);
//           setRole("admin");
//           Swal.fire("Admin", obj.message || "Login successful", "success");
//           navigate("/dashboard");
//         } else {
//           Swal.fire(
//             "Failed",
//             obj.message || "Invalid admin credentials",
//             "error"
//           );
//         }
//       }
//     } catch (err) {
//       console.error("Login error:", err);
//       Swal.fire(
//         "Error",
//         "Something went wrong. Please try again later.",
//         "error"
//       );
//     }
//   };

//   return (
//     <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
//       <div
//         className="card shadow-lg p-4"
//         style={{ width: "400px", borderRadius: "15px" }}
//       >
//         <h3 className="text-center mb-4">Login</h3>
//         <form onSubmit={handleSubmit(onSubmit)} className="row g-3">
//           {/* Role Selection */}
//           <div className="col-12">
//             <label className="form-label">Login as</label>
//             <select className="form-select" {...register("role")} required>
//               <option value="" className="form-label">
//                 -- Select Role --
//               </option>
//               <option value="customer">Customer</option>
//               <option value="admin">Admin</option>
//             </select>
//           </div>

//           {/* Email */}
//           <div className="col-12">
//             <label className="form-label">Email</label>
//             <input
//               type="email"
//               className="form-control"
//               placeholder="Enter email"
//               {...register("email")}
//               required
//             />
//           </div>

//           {/* Password */}
//           <div className="col-12">
//             <label className="form-label">Password</label>
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Enter password"
//               {...register("password")}
//               required
//             />
//           </div>

//           {/* Submit */}
//           <div className="col-12 d-grid">
//             <button className="btn btn-primary">
//               <i className="bi bi-box-arrow-in-right"></i> Login
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// }

// -------------------------------------------------------------------------------------------------------------

// import React, { useContext } from "react";
// import { useForm } from "react-hook-form";
// import Swal from "sweetalert2";
// import { LoginContext } from "../context/LoginContext";
// import { useNavigate } from "react-router-dom";

// const BASE = "http://localhost:8080";

// export default function Login() {
//   const { register, handleSubmit } = useForm();
//   const { setIsLogin, setUserId, setRole, setUserName } =
//     useContext(LoginContext);
//   const navigate = useNavigate();

//   const onSubmit = async (form) => {
//     if (form.role === "customer") {
//       const res = await fetch(`${BASE}/api/customers/login`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ email: form.email, password: form.password }),
//       });

//       const obj = await res.json();
//       if (res.ok) {
//         const user = obj.data;
//         setIsLogin(true);
//         setUserId(user?.id ?? null);
//         setRole("customer");
//         setUserName(user?.name ?? ""); // 👈 save name
//         Swal.fire("Welcome", obj.message || "Login successful", "success");
//         navigate("/");
//       } else {
//         Swal.fire(
//           "Failed",
//           obj.message || "Invalid customer credentials",
//           "error"
//         );
//       }
//     }

//     if (form.role === "admin") {
//       const res = await fetch(`${BASE}/api/admin/login`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ email: form.email, password: form.password }),
//       });

//       const obj = await res.json();
//       if (res.ok) {
//         const admin = obj.data;
//         setIsLogin(true);
//         setUserId(admin?.id ?? null);
//         setRole("admin");
//         setUserName(admin?.name ?? ""); // 👈 save name
//         Swal.fire("Admin", obj.message || "Login successful", "success");
//         navigate("/dashboard");
//       } else {
//         Swal.fire(
//           "Failed",
//           obj.message || "Invalid admin credentials",
//           "error"
//         );
//       }
//     }
//   };

//   return (
//     <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
//       <div
//         className="card shadow-lg p-4"
//         style={{ width: "400px", borderRadius: "15px" }}
//       >
//         <h3 className="text-center mb-4">Login</h3>
//         <form onSubmit={handleSubmit(onSubmit)} className="row g-3">
//           {/* Role Selection */}
//           <div className="col-12">
//             <label className="form-label">Login as</label>
//             <select className="form-select" {...register("role")} required>
//               <option value="">-- Select Role --</option>
//               <option value="customer">Customer</option>
//               <option value="admin">Admin</option>
//             </select>
//           </div>

//           {/* Email */}
//           <div className="col-12">
//             <label className="form-label">Email</label>
//             <input
//               type="email"
//               className="form-control"
//               placeholder="Enter email"
//               {...register("email")}
//               required
//             />
//           </div>

//           {/* Password */}
//           <div className="col-12">
//             <label className="form-label">Password</label>
//             <input
//               type="password"
//               className="form-control"
//               placeholder="Enter password"
//               {...register("password")}
//               required
//             />
//           </div>

//           {/* Submit */}
//           <div className="col-12 d-grid">
//             <button className="btn btn-primary">
//               <i className="bi bi-box-arrow-in-right"></i> Login
//             </button>
//           </div>

//           <div className="col-12 text-center mt-3">
//             <p className="mb-0">
//               Don't have an account? <a href="/register">Register here</a>
//             </p>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// }

import React, { useContext } from "react";
import { useForm } from "react-hook-form";
import Swal from "sweetalert2";
import { LoginContext } from "../context/LoginContext";
import { useNavigate } from "react-router-dom";

const BASE = "http://localhost:8080";

export default function Login() {
  const { register, handleSubmit } = useForm();
  const { setIsLogin, setUserId, setRole, setUserName } =
    useContext(LoginContext);
  const navigate = useNavigate();

  const onSubmit = async (form) => {
    if (form.role === "customer") {
      const res = await fetch(`${BASE}/api/customers/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, password: form.password }),
      });

      const obj = await res.json();
      if (res.ok) {
        const user = obj.data;

        // 👉 Save to context
        setIsLogin(true);
        setUserId(user?.id ?? null);
        setRole("customer");
        setUserName(user?.name ?? "");

        // 👉 Save to sessionStorage
        sessionStorage.setItem("userId", user?.id ?? "");
        sessionStorage.setItem("userName", user?.name ?? "");
        sessionStorage.setItem("role", "customer");

        Swal.fire("Welcome", obj.message || "Login successful", "success");
        navigate("/");
      } else {
        Swal.fire(
          "Failed",
          obj.message || "Invalid customer credentials",
          "error"
        );
      }
    }

    if (form.role === "admin") {
      const res = await fetch(`${BASE}/api/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, password: form.password }),
      });

      const obj = await res.json();
      if (res.ok) {
        const admin = obj.data;

        // 👉 Save to context
        setIsLogin(true);
        setUserId(admin?.id ?? null);
        setRole("admin");
        setUserName(admin?.name ?? "");

        // 👉 Save to sessionStorage
        sessionStorage.setItem("userId", admin?.id ?? "");
        sessionStorage.setItem("userName", admin?.name ?? "");
        sessionStorage.setItem("role", "admin");

        Swal.fire("Admin", obj.message || "Login successful", "success");
        navigate("/dashboard");
      } else {
        Swal.fire(
          "Failed",
          obj.message || "Invalid admin credentials",
          "error"
        );
      }
    }
  };

  return (
    <div className="container-fluid">
      <button
        className="btn btn-outline-dark"
        onClick={() => {
          navigate("/");
        }}
      >
        Home
      </button>
      <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
        <div
          className="card shadow-lg p-4"
          style={{ width: "400px", borderRadius: "15px" }}
        >
          <h3 className="text-center mb-4">Login</h3>
          <form onSubmit={handleSubmit(onSubmit)} className="row g-3">
            <div className="col-12">
              <label className="form-label">Login as</label>
              <select className="form-select" {...register("role")} required>
                <option value="">-- Select Role --</option>
                <option value="customer">Customer</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <div className="col-12">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-control"
                placeholder="Enter email"
                {...register("email")}
                required
              />
            </div>

            <div className="col-12">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                placeholder="Enter password"
                {...register("password")}
                required
              />
            </div>

            <div className="col-12 d-grid">
              <button className="btn btn-primary">
                <i className="bi bi-box-arrow-in-right"></i> Login
              </button>
            </div>

            <div className="col-12 text-center mt-3">
              <p className="mb-0">
                Don't have an account? <a href="/register">Register here</a>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
